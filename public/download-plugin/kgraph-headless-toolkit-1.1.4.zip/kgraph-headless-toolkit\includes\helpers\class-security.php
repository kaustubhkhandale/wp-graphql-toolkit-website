<?php
/**
 * Security Helper Class
 *
 * @package HeadlessWPGraphQLToolkit
 */

namespace HeadlessWPGraphQLToolkit\Helpers;

/**
 * Security class - handles all security-related operations.
 */
class Security {

	/**
	 * Verify nonce.
	 *
	 * @param string $nonce Nonce to verify.
	 * @param string $action Action name.
	 * @param bool   $die Whether to die on failure.
	 * @return bool|int
	 */
	public static function verify_nonce( $nonce, $action, $die = false ) {
		$nonce  = is_string( $nonce ) ? sanitize_text_field( wp_unslash( $nonce ) ) : '';
		$action = is_string( $action ) ? sanitize_key( $action ) : '';

		$verified = wp_verify_nonce( $nonce, $action );

		if ( ! $verified && $die ) {
			wp_die(
				esc_html__( 'Security check failed.', 'kgraph-headless-toolkit' ),
				esc_html__( 'Unauthorized', 'kgraph-headless-toolkit' ),
				403
			);
		}

		return $verified;
	}

	/**
	 * Check user capability.
	 *
	 * @param string $capability Capability to check.
	 * @param bool   $die Whether to die on failure.
	 * @return bool
	 */
	public static function check_capability( $capability = '', $die = false ) {
		if ( ! $capability ) {
			$capability = HWGT_CAPABILITY;
		}

		$can = current_user_can( $capability );

		if ( ! $can && $die ) {
			wp_die(
				esc_html__( 'You do not have permission to access this page.', 'kgraph-headless-toolkit' ),
				esc_html__( 'Forbidden', 'kgraph-headless-toolkit' ),
				403
			);
		}

		return $can;
	}

	/**
	 * Sanitize text input.
	 *
	 * @param mixed $input Input to sanitize.
	 * @return string
	 */
	public static function sanitize_input( $input ) {
		if ( is_array( $input ) ) {
			return array_map( array( self::class, 'sanitize_input' ), $input );
		}

		return sanitize_text_field( $input );
	}

	/**
	 * Sanitize JSON input.
	 *
	 * @param string $input JSON string to sanitize.
	 * @return array|object
	 */
	public static function sanitize_json( $input ) {
		$decoded = json_decode( $input, true );

		if ( json_last_error() !== JSON_ERROR_NONE ) {
			return array();
		}

		return self::sanitize_input( $decoded );
	}

	/**
	 * Escape HTML output.
	 *
	 * @param mixed $text Text to escape.
	 * @return string
	 */
	public static function esc_html_output( $text ) {
		return esc_html( $text );
	}

	/**
	 * Escape HTML attribute.
	 *
	 * @param mixed $attr Attribute to escape.
	 * @return string
	 */
	public static function esc_attr_output( $attr ) {
		return esc_attr( $attr );
	}

	/**
	 * Create nonce field.
	 *
	 * @param string $action Action name.
	 * @param string $name Field name.
	 * @return void
	 */
	public static function nonce_field( $action, $name = '_wpnonce' ) {
		wp_nonce_field( $action, $name );
	}

	/**
	 * Get nonce.
	 *
	 * @param string $action Action name.
	 * @return string
	 */
	public static function get_nonce( $action ) {
		return wp_create_nonce( $action );
	}
}
