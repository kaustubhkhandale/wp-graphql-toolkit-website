<?php
/**
 * Admin Class
 *
 * @package HeadlessWPGraphQLToolkit
 */

namespace HeadlessWPGraphQLToolkit\Admin;

use HeadlessWPGraphQLToolkit\Helpers\Constants;
use HeadlessWPGraphQLToolkit\Helpers\Security;
use HeadlessWPGraphQLToolkit\Integrations\WPGraphQL_Compatibility;

/**
 * Admin class - handles admin menu and page setup.
 */
class Admin {

	/**
	 * Admin constructor.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_styles' ) );
		add_action( 'admin_notices', array( $this, 'render_compatibility_notice' ) );
	}

	/**
	 * Add admin menu page.
	 *
	 * @return void
	 */
	public function add_admin_menu() {
		add_menu_page(
			esc_html__( 'KGraph Headless Toolkit', 'kgraph-headless-toolkit' ),
			esc_html__( 'KGraph Toolkit', 'kgraph-headless-toolkit' ),
			HWGT_CAPABILITY,
			'kgraph-headless-toolkit',
			array( $this, 'render_admin_page' ),
			$this->get_menu_icon(),
			76
		);
	}

	/**
	 * Get admin menu icon.
	 *
	 * @return string
	 */
	private function get_menu_icon() {
		$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="black" d="M10 1.5 12.8 6l5.2.7-3.8 3.7.9 5.2L10 13.2l-5.1 2.6.9-5.2L2 6.7 7.2 6 10 1.5Zm0 3.8-1.5 2.5-2.9.4 2.1 2-.5 2.9 2.8-1.4 2.8 1.4-.5-2.9 2.1-2-2.9-.4L10 5.3Z"/></svg>';

		return 'data:image/svg+xml;base64,' . base64_encode( $svg );
	}

	/**
	 * Render admin page.
	 *
	 * @return void
	 */
	public function render_admin_page() {
		// Check capability.
		if ( ! Security::check_capability( HWGT_CAPABILITY ) ) {
			esc_html_e( 'You do not have permission to access this page.', 'kgraph-headless-toolkit' );
			return;
		}
		?>
		<div id="hwgt-root" class="hwgt-root-fallback">
			<div style="padding:24px;background:#fff;border:1px solid #dcdcde;margin:16px 0;">
				<strong><?php esc_html_e( 'GraphQL Toolkit is loading...', 'kgraph-headless-toolkit' ); ?></strong>
				<p><?php esc_html_e( 'If this message stays visible, the admin JavaScript bundle did not load.', 'kgraph-headless-toolkit' ); ?></p>
			</div>
		</div>
		<?php
	}

	/**
	 * Show a compatibility warning when schema tools cannot operate safely.
	 *
	 * @return void
	 */
	public function render_compatibility_notice() {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( 'kgraph-headless-toolkit' !== $page ) {
			return;
		}

		$status = WPGraphQL_Compatibility::get_status();
		if ( $status['ready'] ) {
			return;
		}
		?>
		<div class="notice notice-warning">
			<p>
				<strong><?php esc_html_e( 'GraphQL Toolkit compatibility warning:', 'kgraph-headless-toolkit' ); ?></strong>
				<?php echo esc_html( $status['message'] ); ?>
				<?php esc_html_e( 'Saved Queries and Templates remain available.', 'kgraph-headless-toolkit' ); ?>
			</p>
		</div>
		<?php
	}

	/**
	 * Enqueue admin scripts.
	 *
	 * @param string $hook_suffix Admin page hook suffix.
	 * @return void
	 */
	public function enqueue_scripts( $hook_suffix ) {
		// Only enqueue on plugin pages.
		if ( ! $this->is_plugin_page( $hook_suffix ) ) {
			return;
		}

		// Get manifest file for Vite build.
		$manifest_file = Constants::plugin_dir( 'build/manifest.json' );

		if ( ! file_exists( $manifest_file ) ) {
			// Development mode - load from Vite dev server.
			if ( Constants::version() === 'dev' || defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				$dev_server = 'http://localhost:5173/wp-content/plugins/kgraph-headless-toolkit/build';

				wp_enqueue_script(
					'hwgt-react',
					$dev_server . '/@vite/client',
					array(),
					Constants::version(),
					true
				);
				wp_enqueue_script(
					'hwgt-app',
					$dev_server . '/admin/src/main.tsx',
					array( 'hwgt-react' ),
					Constants::version(),
					true
				);

				wp_script_add_data( 'hwgt-react', 'type', 'module' );
				wp_script_add_data( 'hwgt-app', 'type', 'module' );
				return;
			}
			return;
		}

		// Production mode - load from manifest.
		$manifest = json_decode( file_get_contents( $manifest_file ), true );

		if ( isset( $manifest['admin/src/main.tsx'] ) ) {
			$entry = $manifest['admin/src/main.tsx'];

			// Enqueue main script.
			wp_enqueue_script(
				'hwgt-app',
				Constants::plugin_url( 'build/' . $entry['file'] ),
				array(),
				Constants::version(),
				true
			);
			wp_script_add_data( 'hwgt-app', 'type', 'module' );

			// Enqueue CSS if present.
			if ( isset( $entry['css'] ) && ! empty( $entry['css'] ) ) {
				foreach ( $entry['css'] as $css_file ) {
					wp_enqueue_style(
						'hwgt-app-' . sanitize_file_name( $css_file ),
						Constants::plugin_url( 'build/' . $css_file ),
						array(),
						Constants::version()
					);
				}
			}

			// Enqueue vendor scripts if present.
			if ( isset( $entry['imports'] ) && ! empty( $entry['imports'] ) ) {
				foreach ( $entry['imports'] as $import_key ) {
					if ( isset( $manifest[ $import_key ] ) ) {
						$import_file = $manifest[ $import_key ];
						wp_enqueue_script(
							'hwgt-vendor-' . sanitize_file_name( $import_key ),
						Constants::plugin_url( 'build/' . $import_file['file'] ),
						array(),
						Constants::version(),
						true
					);
					wp_script_add_data( 'hwgt-vendor-' . sanitize_file_name( $import_key ), 'type', 'module' );
				}
			}
		}
		}

		// Localize script data.
		$wpgraphql_status = WPGraphQL_Compatibility::get_status();
		$release_notes_file = Constants::plugin_dir( 'release-notes.json' );
		$release_notes      = file_exists( $release_notes_file )
			? json_decode( file_get_contents( $release_notes_file ), true )
			: array();
		$support_url        = apply_filters(
			'hwgt_support_url',
			'upi://pay?pa=kaustubhkhandale@oksbi&pn=Kaustubh%20Khandale&cu=INR'
		);
		$support_protocols  = array( 'http', 'https', 'upi' );
		$support_url        = is_string( $support_url ) ? esc_url_raw( $support_url, $support_protocols ) : '';
		$support_label      = apply_filters(
			'hwgt_support_label',
			esc_html__( 'Donate if this toolkit helps your work', 'kgraph-headless-toolkit' )
		);
		$support_description = apply_filters(
			'hwgt_support_description',
			esc_html__( 'Donations are optional and do not unlock or restrict any plugin features.', 'kgraph-headless-toolkit' )
		);

		wp_localize_script(
			'hwgt-app',
			'hwgtData',
			array(
				'apiUrl'     => rest_url( HWGT_REST_NAMESPACE ),
				'nonce'      => Security::get_nonce( 'wp_rest' ),
				'capability' => HWGT_CAPABILITY,
				'userCan'    => Security::check_capability( HWGT_CAPABILITY ),
				'version'    => HWGT_VERSION,
				'wpVersion'  => get_bloginfo( 'version' ),
				'graphql'    => $wpgraphql_status['ready'],
				'wpgraphql'  => $wpgraphql_status,
				'releaseNotes' => is_array( $release_notes ) ? $release_notes : array(),
				'support'    => array(
					'enabled'     => '' !== $support_url,
					'url'         => $support_url,
					'label'       => is_string( $support_label ) ? sanitize_text_field( $support_label ) : '',
					'description' => is_string( $support_description ) ? sanitize_text_field( $support_description ) : '',
				),
			)
		);
	}

	/**
	 * Enqueue admin styles.
	 *
	 * @param string $hook_suffix Admin page hook suffix.
	 * @return void
	 */
	public function enqueue_styles( $hook_suffix ) {
		// Only enqueue on plugin pages.
		if ( ! $this->is_plugin_page( $hook_suffix ) ) {
			return;
		}

		if ( ! file_exists( Constants::plugin_dir( 'build/main.css' ) ) ) {
			return;
		}

		// Enqueue main stylesheet (loaded via JS import in Vite).
		wp_enqueue_style(
			'hwgt-tailwind',
			Constants::plugin_url( 'build/main.css' ),
			array(),
			Constants::version()
		);
	}

	/**
	 * Check whether the current admin screen belongs to this plugin.
	 *
	 * @param string $hook_suffix Admin page hook suffix.
	 * @return bool
	 */
	private function is_plugin_page( $hook_suffix ) {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		return 'kgraph-headless-toolkit' === $page
			|| 'toplevel_page_kgraph-headless-toolkit' === $hook_suffix
			|| false !== strpos( $hook_suffix, 'kgraph-headless-toolkit' );
	}
}
