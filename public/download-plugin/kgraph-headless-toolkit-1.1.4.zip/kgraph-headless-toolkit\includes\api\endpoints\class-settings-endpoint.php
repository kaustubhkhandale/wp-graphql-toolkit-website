<?php
/**
 * Plugin settings endpoint.
 *
 * @package HeadlessWPGraphQLToolkit
 */

namespace HeadlessWPGraphQLToolkit\API\Endpoints;

use HeadlessWPGraphQLToolkit\Helpers\Security;

/**
 * Manages server-side plugin settings.
 */
class Settings_Endpoint {

	/**
	 * Register settings routes.
	 *
	 * @return void
	 */
	public static function register() {
		register_rest_route(
			HWGT_REST_NAMESPACE,
			'/settings',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( self::class, 'get_settings' ),
					'permission_callback' => array( self::class, 'check_permission' ),
				),
				array(
					'methods'             => 'PUT',
					'callback'            => array( self::class, 'update_settings' ),
					'permission_callback' => array( self::class, 'check_permission' ),
					'args'                => array(
						'delete_data_on_uninstall' => array(
							'type'     => 'boolean',
							'required' => true,
						),
					),
				),
			)
		);
	}

	/**
	 * Get server-side settings.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response
	 */
	public static function get_settings( $request ) {
		if ( ! self::verify_nonce( $request ) ) {
			return new \WP_REST_Response( array( 'error' => 'Invalid nonce' ), 403 );
		}

		return new \WP_REST_Response(
			array(
				'success'                  => true,
				'delete_data_on_uninstall' => (bool) get_option( 'hwgt_delete_data_on_uninstall', false ),
			),
			200
		);
	}

	/**
	 * Update server-side settings.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response
	 */
	public static function update_settings( $request ) {
		if ( ! self::verify_nonce( $request ) ) {
			return new \WP_REST_Response( array( 'error' => 'Invalid nonce' ), 403 );
		}

		$delete_data = rest_sanitize_boolean( $request->get_param( 'delete_data_on_uninstall' ) );
		update_option( 'hwgt_delete_data_on_uninstall', $delete_data, false );

		return new \WP_REST_Response(
			array(
				'success'                  => true,
				'delete_data_on_uninstall' => $delete_data,
				'message'                  => 'Settings saved successfully',
			),
			200
		);
	}

	/**
	 * Verify request nonce.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return bool
	 */
	private static function verify_nonce( $request ) {
		return Security::verify_nonce( $request->get_header( 'X-WP-Nonce' ), 'wp_rest' );
	}

	/**
	 * Check user capability.
	 *
	 * @return bool
	 */
	public static function check_permission() {
		return current_user_can( 'manage_options' );
	}
}
