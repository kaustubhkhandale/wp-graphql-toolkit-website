<?php
/**
 * Templates Endpoint Handler
 *
 * @package HeadlessWPGraphQLToolkit
 */

namespace HeadlessWPGraphQLToolkit\API\Endpoints;

use HeadlessWPGraphQLToolkit\Helpers\Security;
use HeadlessWPGraphQLToolkit\Database\Database;

/**
 * Templates endpoint - list available query templates.
 */
class Templates_Endpoint {

	/**
	 * Built-in templates.
	 *
	 * @var array
	 */
	private static $builtin_templates = array(
		array(
			'id'             => 'get-posts',
			'name'           => 'Get Latest Posts',
			'description'    => 'Retrieve latest posts with title and content',
			'query_type'     => 'query',
			'category'       => 'Posts',
			'query_content'  => 'query GetLatestPosts {
  posts(first: 10) {
    edges {
      node {
        id
        title
        excerpt
        date
        uri
      }
    }
  }
}',
		),
		array(
			'id'             => 'get-pages',
			'name'           => 'Get Pages',
			'description'    => 'Retrieve site pages with hierarchy',
			'query_type'     => 'query',
			'category'       => 'Pages',
			'query_content'  => 'query GetPages {
  pages(first: 10) {
    edges {
      node {
        id
        title
        uri
        children {
          nodes {
            id
            title
            uri
          }
        }
      }
    }
  }
}',
		),
		array(
			'id'             => 'get-categories',
			'name'           => 'Get Categories',
			'description'    => 'Retrieve post categories with count',
			'query_type'     => 'query',
			'category'       => 'Categories',
			'query_content'  => 'query GetCategories {
  categories(first: 20) {
    edges {
      node {
        id
        name
        slug
        count
        description
      }
    }
  }
}',
		),
		array(
			'id'             => 'get-navigation-menus',
			'name'           => 'Get Navigation Menus',
			'description'    => 'Retrieve site menus with their navigation items',
			'query_type'     => 'query',
			'category'       => 'Navigation',
			'query_content'  => 'query GetNavigationMenus {
  menus(first: 20) {
    nodes {
      id
      databaseId
      name
      slug
      locations
      menuItems(first: 100) {
        nodes {
          id
          databaseId
          label
          path
          url
          parentId
          target
          cssClasses
        }
      }
    }
  }
}',
		),
		array(
			'id'             => 'get-tags',
			'name'           => 'Get Tags',
			'description'    => 'Retrieve post tags with usage counts and descriptions',
			'query_type'     => 'query',
			'category'       => 'Tags',
			'query_content'  => 'query GetTags {
  tags(first: 50) {
    nodes {
      id
      databaseId
      name
      slug
      count
      description
    }
  }
}',
		),
		array(
			'id'             => 'get-media-library',
			'name'           => 'Get Media Library',
			'description'    => 'Retrieve media files with URLs, dimensions, and alt text',
			'query_type'     => 'query',
			'category'       => 'Media',
			'query_content'  => 'query GetMediaLibrary {
  mediaItems(first: 20) {
    nodes {
      id
      databaseId
      title
      altText
      caption
      sourceUrl
      mimeType
      mediaDetails {
        width
        height
        sizes {
          name
          sourceUrl
          width
          height
        }
      }
    }
  }
}',
		),
	);

	/**
	 * Register the templates endpoint.
	 *
	 * @return void
	 */
	public static function register() {
		register_rest_route(
			HWGT_REST_NAMESPACE,
			'/templates',
			array(
				'methods'             => 'GET',
				'callback'            => array( self::class, 'get_templates' ),
				'permission_callback' => array( self::class, 'check_permission' ),
			)
		);
	}

	/**
	 * Get all available templates.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response Response object.
	 */
	public static function get_templates( $request ) {
		// Check nonce
		if ( ! Security::verify_nonce( $request->get_header( 'X-WP-Nonce' ), 'wp_rest' ) ) {
			return new \WP_REST_Response(
				array( 'error' => 'Invalid nonce' ),
				403
			);
		}

		try {
			// Get user templates
			$current_user  = wp_get_current_user();
			$user_templates = Database::get_user_queries( $current_user->ID );

			// Format user templates
			$formatted_user_templates = array_map(
				function( $template ) {
					return array(
						'id'             => (int) $template->id,
						'name'           => $template->name,
						'description'    => $template->description,
						'query_type'     => $template->query_type,
						'category'       => 'Saved',
						'query_content'  => $template->query_content,
						'is_user_saved'  => true,
						'created_at'     => $template->created_at,
					);
				},
				$user_templates
			);

			$all_templates = array_merge( self::$builtin_templates, $formatted_user_templates );

			return new \WP_REST_Response(
				array(
					'success'   => true,
					'templates' => $all_templates,
					'total'     => count( $all_templates ),
				),
				200
			);
		} catch ( \Exception $e ) {
			return new \WP_REST_Response(
				array( 'error' => $e->getMessage() ),
				500
			);
		}
	}

	/**
	 * Check if user has permission.
	 *
	 * @return bool
	 */
	public static function check_permission() {
		return current_user_can( 'manage_options' );
	}
}
