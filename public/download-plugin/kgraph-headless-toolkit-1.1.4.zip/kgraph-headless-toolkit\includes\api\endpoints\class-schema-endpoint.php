<?php
/**
 * Schema Endpoint Handler
 *
 * @package HeadlessWPGraphQLToolkit
 */

namespace HeadlessWPGraphQLToolkit\API\Endpoints;

use HeadlessWPGraphQLToolkit\Helpers\Security;
use HeadlessWPGraphQLToolkit\Integrations\WPGraphQL_Compatibility;

/**
 * Schema endpoint - retrieves GraphQL schema.
 */
class Schema_Endpoint {

	/**
	 * Register the schema endpoint.
	 *
	 * @return void
	 */
	public static function register() {
		register_rest_route(
			HWGT_REST_NAMESPACE,
			'/schema',
			array(
				'methods'             => 'GET',
				'callback'            => array( self::class, 'get_schema' ),
				'permission_callback' => array( self::class, 'check_permission' ),
			)
		);
	}

	/**
	 * Get GraphQL schema.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response Response object.
	 */
	public static function get_schema( $request ) {
		// Check nonce
		if ( ! Security::verify_nonce( $request->get_header( 'X-WP-Nonce' ), 'wp_rest' ) ) {
			return new \WP_REST_Response(
				array( 'error' => 'Invalid nonce' ),
				403
			);
		}

		$status = WPGraphQL_Compatibility::get_status();
		if ( ! $status['ready'] ) {
			return new \WP_REST_Response(
				array(
					'error'  => $status['message'],
					'code'   => 'hwgt_wpgraphql_unavailable',
					'status' => $status,
				),
				503
			);
		}

		try {
			$result = WPGraphQL_Compatibility::execute( self::get_introspection_query() );

			if ( isset( $result['errors'] ) && ! empty( $result['errors'] ) ) {
				return new \WP_REST_Response(
					array( 'error' => 'Schema introspection failed', 'details' => $result['errors'] ),
					400
				);
			}

			return new \WP_REST_Response(
				array(
					'success' => true,
					'schema'  => $result['data'] ?? array(),
				),
				200
			);
		} catch ( \Throwable $e ) {
			return new \WP_REST_Response(
				array( 'error' => $e->getMessage() ),
				500
			);
		}
	}

	/**
	 * Get a GraphQL introspection query.
	 *
	 * @return string
	 */
	private static function get_introspection_query() {
		return 'query IntrospectionQuery {
			__schema {
				queryType { name }
				mutationType { name }
				subscriptionType { name }
				types {
					kind
					name
					description
					fields(includeDeprecated: true) {
						name
						description
						isDeprecated
						deprecationReason
						args {
							name
							description
							defaultValue
							type {
								kind
								name
								ofType {
									kind
									name
									ofType {
										kind
										name
										ofType {
											kind
											name
										}
									}
								}
							}
						}
						type {
							kind
							name
							ofType {
								kind
								name
								ofType {
									kind
									name
									ofType {
										kind
										name
									}
								}
							}
						}
					}
					inputFields {
						name
						description
						defaultValue
						type {
							kind
							name
							ofType {
								kind
								name
								ofType {
									kind
									name
								}
							}
						}
					}
					enumValues(includeDeprecated: true) {
						name
						description
						isDeprecated
						deprecationReason
					}
				}
			}
		}';
	}

	/**
	 * Check if user has permission.
	 *
	 * @return bool
	 */
	public static function check_permission() {
		return current_user_can( 'manage_options' );
	}
}
