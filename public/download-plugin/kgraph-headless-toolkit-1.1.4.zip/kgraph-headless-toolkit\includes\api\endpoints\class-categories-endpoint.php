<?php
/**
 * Template Categories Endpoint Handler
 *
 * @package HeadlessWPGraphQLToolkit
 */

namespace HeadlessWPGraphQLToolkit\API\Endpoints;

use HeadlessWPGraphQLToolkit\Helpers\Security;
use HeadlessWPGraphQLToolkit\Database\Database;

/**
 * Template categories endpoint - get categories and templates.
 */
class Categories_Endpoint {

	/**
	 * Register the categories endpoints.
	 *
	 * @return void
	 */
	public static function register() {
		// Get all categories
		register_rest_route(
			HWGT_REST_NAMESPACE,
			'/categories',
			array(
				'methods'             => 'GET',
				'callback'            => array( self::class, 'get_categories' ),
				'permission_callback' => array( self::class, 'check_permission' ),
			)
		);

		// Get templates by category
		register_rest_route(
			HWGT_REST_NAMESPACE,
			'/categories/(?P<id>\d+)/templates',
			array(
				'methods'             => 'GET',
				'callback'            => array( self::class, 'get_category_templates' ),
				'permission_callback' => array( self::class, 'check_permission' ),
			)
		);
	}

	/**
	 * Get all template categories.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response Response object.
	 */
	public static function get_categories( $request ) {
		// Check nonce
		if ( ! Security::verify_nonce( $request->get_header( 'X-WP-Nonce' ), 'wp_rest' ) ) {
			return new \WP_REST_Response(
				array( 'error' => 'Invalid nonce' ),
				403
			);
		}

		try {
			$categories = Database::get_categories();

			$formatted_categories = array_map(
				function( $category ) {
					return array(
						'id'              => (int) $category->id,
						'name'            => $category->name,
						'slug'            => $category->slug,
						'description'     => $category->description,
						'icon'            => $category->icon,
						'color'           => $category->color,
						'sort_order'      => (int) $category->sort_order,
						'template_count'  => (int) $category->template_count,
					);
				},
				$categories
			);

			return new \WP_REST_Response(
				array(
					'success'     => true,
					'categories'  => $formatted_categories,
					'total'       => count( $formatted_categories ),
				),
				200
			);
		} catch ( \Exception $e ) {
			return new \WP_REST_Response(
				array( 'error' => $e->getMessage() ),
				500
			);
		}
	}

	/**
	 * Get templates for a specific category.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response Response object.
	 */
	public static function get_category_templates( $request ) {
		// Check nonce
		if ( ! Security::verify_nonce( $request->get_header( 'X-WP-Nonce' ), 'wp_rest' ) ) {
			return new \WP_REST_Response(
				array( 'error' => 'Invalid nonce' ),
				403
			);
		}

		try {
			$category_id = (int) $request->get_param( 'id' );
			$current_user = wp_get_current_user();

			$templates = Database::get_templates_by_category( $category_id );

			$formatted_templates = array_map(
				function( $template ) use ( $current_user ) {
					$is_favorited = Database::is_favorited( $current_user->ID, $template->id );

					return array(
						'id'            => (int) $template->id,
						'name'          => $template->name,
						'description'   => $template->description,
						'query_type'    => $template->query_type,
						'query_content' => $template->query_content,
						'usage_count'   => (int) $template->usage_count,
						'created_at'    => $template->created_at,
						'is_favorited'  => $is_favorited,
					);
				},
				$templates
			);

			return new \WP_REST_Response(
				array(
					'success'    => true,
					'templates'  => $formatted_templates,
					'total'      => count( $formatted_templates ),
				),
				200
			);
		} catch ( \Exception $e ) {
			return new \WP_REST_Response(
				array( 'error' => $e->getMessage() ),
				500
			);
		}
	}

	/**
	 * Check if user has permission.
	 *
	 * @return bool
	 */
	public static function check_permission() {
		return current_user_can( 'manage_options' );
	}
}
