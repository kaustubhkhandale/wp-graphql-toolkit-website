<?php
/**
 * Runtime status endpoint.
 *
 * @package HeadlessWPGraphQLToolkit
 */

namespace HeadlessWPGraphQLToolkit\API\Endpoints;

use HeadlessWPGraphQLToolkit\Helpers\Security;
use HeadlessWPGraphQLToolkit\Integrations\WPGraphQL_Compatibility;

/**
 * Exposes dependency compatibility information for diagnostics.
 */
class Status_Endpoint {

	/**
	 * Register the status endpoint.
	 *
	 * @return void
	 */
	public static function register() {
		register_rest_route(
			HWGT_REST_NAMESPACE,
			'/status',
			array(
				'methods'             => 'GET',
				'callback'            => array( self::class, 'get_status' ),
				'permission_callback' => array( self::class, 'check_permission' ),
			)
		);
	}

	/**
	 * Get plugin and WPGraphQL compatibility status.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response
	 */
	public static function get_status( $request ) {
		if ( ! Security::verify_nonce( $request->get_header( 'X-WP-Nonce' ), 'wp_rest' ) ) {
			return new \WP_REST_Response( array( 'error' => 'Invalid nonce' ), 403 );
		}

		return new \WP_REST_Response(
			array(
				'success'   => true,
				'plugin'    => array(
					'version'   => HWGT_VERSION,
					'wpVersion' => get_bloginfo( 'version' ),
					'phpVersion' => PHP_VERSION,
				),
				'wpgraphql' => WPGraphQL_Compatibility::get_status(),
			),
			200
		);
	}

	/**
	 * Check whether the current user may view status.
	 *
	 * @return bool
	 */
	public static function check_permission() {
		return current_user_can( 'manage_options' );
	}
}
