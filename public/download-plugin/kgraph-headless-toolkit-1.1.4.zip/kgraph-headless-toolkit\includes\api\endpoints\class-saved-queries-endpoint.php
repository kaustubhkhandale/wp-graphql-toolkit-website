<?php
/**
 * Saved Queries Endpoint Handler
 *
 * @package HeadlessWPGraphQLToolkit
 */

namespace HeadlessWPGraphQLToolkit\API\Endpoints;

use HeadlessWPGraphQLToolkit\Helpers\Security;
use HeadlessWPGraphQLToolkit\Database\Database;

/**
 * Saved queries endpoint - manage user's saved queries.
 */
class Saved_Queries_Endpoint {

	/**
	 * Register the saved queries endpoints.
	 *
	 * @return void
	 */
	public static function register() {
		// List saved queries
		register_rest_route(
			HWGT_REST_NAMESPACE,
			'/queries',
			array(
				'methods'             => 'GET',
				'callback'            => array( self::class, 'get_saved_queries' ),
				'permission_callback' => array( self::class, 'check_permission' ),
			)
		);

		// Create saved query
		register_rest_route(
			HWGT_REST_NAMESPACE,
			'/queries',
			array(
				'methods'             => 'POST',
				'callback'            => array( self::class, 'save_query' ),
				'permission_callback' => array( self::class, 'check_permission' ),
				'args'                => array(
					'name'           => array(
						'type'        => 'string',
						'required'    => true,
						'description' => 'Query name',
					),
					'description'    => array(
						'type'        => 'string',
						'required'    => false,
						'description' => 'Query description',
					),
					'query_type'     => array(
						'type'        => 'string',
						'required'    => true,
						'description' => 'Query type (query, mutation, etc)',
					),
					'query_content'  => array(
						'type'        => 'string',
						'required'    => true,
						'description' => 'GraphQL query content',
					),
					'variables'      => array(
						'type'        => 'object',
						'required'    => false,
						'description' => 'Query variables',
					),
					'tags'           => array(
						'type'        => 'string',
						'required'    => false,
						'description' => 'Query tags (comma-separated)',
					),
				),
			)
		);

		// Update/Delete specific query
		register_rest_route(
			HWGT_REST_NAMESPACE,
			'/queries/(?P<id>\d+)',
			array(
				array(
					'methods'             => 'PUT',
					'callback'            => array( self::class, 'update_query' ),
					'permission_callback' => array( self::class, 'check_permission' ),
				),
				array(
					'methods'             => 'DELETE',
					'callback'            => array( self::class, 'delete_query' ),
					'permission_callback' => array( self::class, 'check_permission' ),
				),
			)
		);
	}

	/**
	 * Get all saved queries for current user.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response Response object.
	 */
	public static function get_saved_queries( $request ) {
		// Check nonce
		if ( ! Security::verify_nonce( $request->get_header( 'X-WP-Nonce' ), 'wp_rest' ) ) {
			return new \WP_REST_Response(
				array( 'error' => 'Invalid nonce' ),
				403
			);
		}

		try {
			$current_user = wp_get_current_user();
			$query_type   = sanitize_key( $request->get_param( 'type' ) );

			$queries = Database::get_user_queries( $current_user->ID, $query_type );

			$formatted_queries = array_map(
				function( $query ) {
					return array(
						'id'             => (int) $query->id,
						'name'           => $query->name,
						'description'    => $query->description,
						'query_type'     => $query->query_type,
						'query_content'  => $query->query_content,
						'variables'      => $query->variables ? json_decode( $query->variables, true ) : null,
						'tags'           => $query->tags,
						'is_template'    => (bool) $query->is_template,
						'created_at'     => $query->created_at,
						'updated_at'     => $query->updated_at,
					);
				},
				$queries
			);

			return new \WP_REST_Response(
				array(
					'success' => true,
					'queries' => $formatted_queries,
					'total'   => count( $formatted_queries ),
				),
				200
			);
		} catch ( \Exception $e ) {
			return new \WP_REST_Response(
				array( 'error' => $e->getMessage() ),
				500
			);
		}
	}

	/**
	 * Save a new query.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response Response object.
	 */
	public static function save_query( $request ) {
		// Check nonce
		if ( ! Security::verify_nonce( $request->get_header( 'X-WP-Nonce' ), 'wp_rest' ) ) {
			return new \WP_REST_Response(
				array( 'error' => 'Invalid nonce' ),
				403
			);
		}

		try {
			$current_user = wp_get_current_user();
			$data         = array(
				'name'           => $request->get_param( 'name' ),
				'description'    => $request->get_param( 'description' ),
				'query_type'     => $request->get_param( 'query_type' ),
				'query_content'  => $request->get_param( 'query_content' ),
				'variables'      => $request->get_param( 'variables' ),
				'tags'           => $request->get_param( 'tags' ),
			);

			$query_id = Database::save_query( $current_user->ID, $data );

			if ( ! $query_id ) {
				return new \WP_REST_Response(
					array( 'error' => 'Failed to save query' ),
					500
				);
			}

			return new \WP_REST_Response(
				array(
					'success'  => true,
					'query_id' => $query_id,
					'message'  => 'Query saved successfully',
				),
				201
			);
		} catch ( \Exception $e ) {
			return new \WP_REST_Response(
				array( 'error' => $e->getMessage() ),
				500
			);
		}
	}

	/**
	 * Update an existing query.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response Response object.
	 */
	public static function update_query( $request ) {
		// Check nonce
		if ( ! Security::verify_nonce( $request->get_header( 'X-WP-Nonce' ), 'wp_rest' ) ) {
			return new \WP_REST_Response(
				array( 'error' => 'Invalid nonce' ),
				403
			);
		}

		try {
			$current_user = wp_get_current_user();
			$query_id     = (int) $request->get_param( 'id' );

			// Verify ownership
			$query = Database::get_query( $query_id, $current_user->ID );
			if ( ! $query ) {
				return new \WP_REST_Response(
					array( 'error' => 'Query not found' ),
					404
				);
			}

			$data = array(
				'name'           => $request->get_param( 'name' ),
				'description'    => $request->get_param( 'description' ),
				'query_type'     => $request->get_param( 'query_type' ),
				'query_content'  => $request->get_param( 'query_content' ),
				'variables'      => $request->get_param( 'variables' ),
				'tags'           => $request->get_param( 'tags' ),
			);

			$success = Database::update_query( $query_id, $current_user->ID, $data );

			if ( ! $success ) {
				return new \WP_REST_Response(
					array( 'error' => 'Failed to update query' ),
					500
				);
			}

			return new \WP_REST_Response(
				array(
					'success' => true,
					'message' => 'Query updated successfully',
				),
				200
			);
		} catch ( \Exception $e ) {
			return new \WP_REST_Response(
				array( 'error' => $e->getMessage() ),
				500
			);
		}
	}

	/**
	 * Delete a query.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response Response object.
	 */
	public static function delete_query( $request ) {
		// Check nonce
		if ( ! Security::verify_nonce( $request->get_header( 'X-WP-Nonce' ), 'wp_rest' ) ) {
			return new \WP_REST_Response(
				array( 'error' => 'Invalid nonce' ),
				403
			);
		}

		try {
			$current_user = wp_get_current_user();
			$query_id     = (int) $request->get_param( 'id' );

			// Verify ownership
			$query = Database::get_query( $query_id, $current_user->ID );
			if ( ! $query ) {
				return new \WP_REST_Response(
					array( 'error' => 'Query not found' ),
					404
				);
			}

			$success = Database::delete_query( $query_id, $current_user->ID );

			if ( ! $success ) {
				return new \WP_REST_Response(
					array( 'error' => 'Failed to delete query' ),
					500
				);
			}

			return new \WP_REST_Response(
				array(
					'success' => true,
					'message' => 'Query deleted successfully',
				),
				200
			);
		} catch ( \Exception $e ) {
			return new \WP_REST_Response(
				array( 'error' => $e->getMessage() ),
				500
			);
		}
	}

	/**
	 * Check if user has permission.
	 *
	 * @return bool
	 */
	public static function check_permission() {
		return current_user_can( 'manage_options' );
	}
}
