<?php
/**
 * Plugin uninstall cleanup.
 *
 * Data is preserved unless an administrator explicitly enables deletion in
 * GraphQL Toolkit settings before uninstalling the plugin.
 *
 * @package HeadlessWPGraphQLToolkit
 */

if ( ! defined( 'ABSPATH' ) || ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

if ( ! get_option( 'hwgt_delete_data_on_uninstall', false ) ) {
	return;
}

global $wpdb;

$hwgt_tables = array(
	$wpdb->prefix . 'hwgt_favorites',
	$wpdb->prefix . 'hwgt_saved_queries',
	$wpdb->prefix . 'hwgt_template_categories',
);

foreach ( $hwgt_tables as $hwgt_table ) {
	$hwgt_table = esc_sql( $hwgt_table );
	$wpdb->query( "DROP TABLE IF EXISTS `$hwgt_table`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
}

delete_option( 'hwgt_settings' );
delete_option( 'hwgt_delete_data_on_uninstall' );
