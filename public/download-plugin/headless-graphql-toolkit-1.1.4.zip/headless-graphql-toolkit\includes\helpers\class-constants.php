<?php
/**
 * Constants Helper Class
 *
 * @package HeadlessWPGraphQLToolkit
 */

namespace HeadlessWPGraphQLToolkit\Helpers;

/**
 * Constants class - provides easy access to plugin constants.
 */
class Constants {

	/**
	 * Get plugin version.
	 *
	 * @return string
	 */
	public static function version() {
		return HWGT_VERSION;
	}

	/**
	 * Get plugin directory path.
	 *
	 * @param string $path Optional path to append.
	 * @return string
	 */
	public static function plugin_dir( $path = '' ) {
		return HWGT_PLUGIN_DIR . $path;
	}

	/**
	 * Get plugin URL.
	 *
	 * @param string $path Optional path to append.
	 * @return string
	 */
	public static function plugin_url( $path = '' ) {
		return HWGT_PLUGIN_URL . $path;
	}

	/**
	 * Get REST namespace.
	 *
	 * @return string
	 */
	public static function rest_namespace() {
		return HWGT_REST_NAMESPACE;
	}

	/**
	 * Get required capability.
	 *
	 * @return string
	 */
	public static function capability() {
		return HWGT_CAPABILITY;
	}

	/**
	 * Get text domain.
	 *
	 * @return string
	 */
	public static function text_domain() {
		return HWGT_TEXT_DOMAIN;
	}
}
