<?php
/**
 * REST API Class
 *
 * @package HeadlessWPGraphQLToolkit
 */

namespace HeadlessWPGraphQLToolkit\API;

use HeadlessWPGraphQLToolkit\Helpers\Security;
use HeadlessWPGraphQLToolkit\Database\Database;
use HeadlessWPGraphQLToolkit\API\Endpoints\Schema_Endpoint;
use HeadlessWPGraphQLToolkit\API\Endpoints\Status_Endpoint;
use HeadlessWPGraphQLToolkit\API\Endpoints\Settings_Endpoint;
use HeadlessWPGraphQLToolkit\API\Endpoints\Templates_Endpoint;
use HeadlessWPGraphQLToolkit\API\Endpoints\Query_Endpoint;
use HeadlessWPGraphQLToolkit\API\Endpoints\Saved_Queries_Endpoint;
use HeadlessWPGraphQLToolkit\API\Endpoints\Categories_Endpoint;
use HeadlessWPGraphQLToolkit\API\Endpoints\Favorites_Endpoint;

/**
 * REST API class - handles REST API registration and endpoints.
 *
 * Phase 3: Core REST API
 * Phase 4: Template categories and favorites
 */
class REST_API {

	/**
	 * REST API constructor.
	 */
	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
		add_action( 'hwgt_init', array( $this, 'init_database' ) );
	}

	/**
	 * Initialize database tables.
	 *
	 * @return void
	 */
	public function init_database() {
		Database::create_tables();
	}

	/**
	 * Register REST API routes.
	 *
	 * Phase 3: Core endpoints
	 * Phase 4: Template categories and favorites
	 *
	 * @return void
	 */
	public function register_routes() {
		// Phase 3 endpoints
		Schema_Endpoint::register();
		Status_Endpoint::register();
		Settings_Endpoint::register();
		Templates_Endpoint::register();
		Query_Endpoint::register();
		Saved_Queries_Endpoint::register();

		// Phase 4 endpoints
		Categories_Endpoint::register();
		Favorites_Endpoint::register();
	}

	/**
	 * Verify request permission.
	 *
	 * @return bool
	 */
	public function verify_request_permission() {
		return Security::check_capability( HWGT_CAPABILITY );
	}

	/**
	 * Verify nonce from request.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return bool
	 */
	public function verify_request_nonce( $request ) {
		$nonce = $request->get_header( 'X-WP-Nonce' );
		return Security::verify_nonce( $nonce, 'wp_rest' );
	}
}
