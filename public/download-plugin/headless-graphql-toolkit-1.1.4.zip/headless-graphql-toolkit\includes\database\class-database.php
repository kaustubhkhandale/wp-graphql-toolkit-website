<?php
/**
 * Database Management Class
 *
 * @package HeadlessWPGraphQLToolkit
 */

namespace HeadlessWPGraphQLToolkit\Database;

/**
 * Database class - handles database tables and migrations.
 */
class Database {

	/**
	 * Initialize database tables.
	 *
	 * Creates database tables for queries, categories, and favorites.
	 *
	 * @return void
	 */
	public static function create_tables() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		// Create saved_queries table
		$queries_table = $wpdb->prefix . 'hwgt_saved_queries';
		$sql_queries    = "CREATE TABLE IF NOT EXISTS $queries_table (
			id bigint(20) NOT NULL AUTO_INCREMENT,
			user_id bigint(20) NOT NULL,
			name varchar(255) NOT NULL,
			description text,
			query_type varchar(50) NOT NULL DEFAULT 'query',
			query_content longtext NOT NULL,
			variables longtext,
			tags varchar(255),
			category_id bigint(20),
			usage_count int(11) DEFAULT 0,
			created_at datetime DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			is_template tinyint(1) DEFAULT 0,
			is_public tinyint(1) DEFAULT 0,
			PRIMARY KEY (id),
			KEY user_id (user_id),
			KEY created_at (created_at),
			KEY query_type (query_type),
			KEY category_id (category_id),
			FULLTEXT KEY name_description (name, description)
		) $charset_collate;";

		// Create categories table
		$categories_table = $wpdb->prefix . 'hwgt_template_categories';
		$sql_categories   = "CREATE TABLE IF NOT EXISTS $categories_table (
			id bigint(20) NOT NULL AUTO_INCREMENT,
			name varchar(255) NOT NULL,
			slug varchar(191) NOT NULL,
			description text,
			icon varchar(50),
			color varchar(7),
			sort_order int(11) DEFAULT 0,
			created_at datetime DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			UNIQUE KEY slug (slug),
			KEY sort_order (sort_order)
		) $charset_collate;";

		// Create favorites table
		$favorites_table = $wpdb->prefix . 'hwgt_favorites';
		$sql_favorites   = "CREATE TABLE IF NOT EXISTS $favorites_table (
			id bigint(20) NOT NULL AUTO_INCREMENT,
			user_id bigint(20) NOT NULL,
			query_id bigint(20) NOT NULL,
			favorited_at datetime DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			UNIQUE KEY user_query (user_id, query_id),
			KEY user_id (user_id)
		) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql_queries );
		dbDelta( $sql_categories );
		dbDelta( $sql_favorites );

		// Insert default categories if not exist
		self::create_default_categories();
	}

	/**
	 * Drop tables on plugin deactivation.
	 *
	 * @return void
	 */
	public static function drop_tables() {
		global $wpdb;
		$wpdb->query( "DROP TABLE IF EXISTS " . $wpdb->prefix . 'hwgt_saved_queries' );
		$wpdb->query( "DROP TABLE IF EXISTS " . $wpdb->prefix . 'hwgt_template_categories' );
		$wpdb->query( "DROP TABLE IF EXISTS " . $wpdb->prefix . 'hwgt_favorites' );
	}

	/**
	 * Create default template categories.
	 *
	 * @return void
	 */
	private static function create_default_categories() {
		global $wpdb;
		$table = $wpdb->prefix . 'hwgt_template_categories';

		$default_categories = array(
			array(
				'name'  => 'Posts',
				'slug'  => 'posts',
				'icon'  => 'description',
				'color' => '#6366F1',
			),
			array(
				'name'  => 'Pages',
				'slug'  => 'pages',
				'icon'  => 'article',
				'color' => '#8B5CF6',
			),
			array(
				'name'  => 'Categories',
				'slug'  => 'categories',
				'icon'  => 'label',
				'color' => '#EC4899',
			),
			array(
				'name'  => 'Tags',
				'slug'  => 'tags',
				'icon'  => 'local_offer',
				'color' => '#F59E0B',
			),
			array(
				'name'  => 'Users',
				'slug'  => 'users',
				'icon'  => 'people',
				'color' => '#10B981',
			),
			array(
				'name'  => 'Media',
				'slug'  => 'media',
				'icon'  => 'image',
				'color' => '#06B6D4',
			),
			array(
				'name'  => 'Navigation',
				'slug'  => 'navigation',
				'icon'  => 'menu',
				'color' => '#3B82F6',
			),
			array(
				'name'  => 'Custom',
				'slug'  => 'custom',
				'icon'  => 'tune',
				'color' => '#6B7280',
			),
		);

		foreach ( $default_categories as $category ) {
			$exists = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT id FROM $table WHERE slug = %s",
					$category['slug']
				)
			);

			if ( ! $exists ) {
				$wpdb->insert(
					$table,
					$category,
					array( '%s', '%s', '%s', '%s' )
				);
			}
		}
	}

	/**
	 * Get all saved queries for a user.
	 *
	 * @param int    $user_id User ID.
	 * @param string $query_type Optional. Query type filter (query, mutation, etc).
	 * @return array Array of saved queries.
	 */
	public static function get_user_queries( $user_id, $query_type = '' ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'hwgt_saved_queries';

		$sql = $wpdb->prepare(
			"SELECT * FROM $table_name WHERE user_id = %d",
			$user_id
		);

		if ( ! empty( $query_type ) ) {
			$sql .= $wpdb->prepare( ' AND query_type = %s', $query_type );
		}

		$sql .= ' ORDER BY created_at DESC';

		return $wpdb->get_results( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
	}

	/**
	 * Save a new query.
	 *
	 * @param int    $user_id User ID.
	 * @param array  $data Query data.
	 * @return int|false Query ID on success, false on failure.
	 */
	public static function save_query( $user_id, $data ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'hwgt_saved_queries';

		$insert_data = array(
			'user_id'        => $user_id,
			'name'           => sanitize_text_field( $data['name'] ?? 'Untitled Query' ),
			'description'    => wp_kses_post( $data['description'] ?? '' ),
			'query_type'     => sanitize_text_field( $data['query_type'] ?? 'query' ),
			'query_content'  => sanitize_textarea_field( $data['query_content'] ?? '' ),
			'variables'      => isset( $data['variables'] ) ? wp_json_encode( $data['variables'] ) : null,
			'tags'           => sanitize_text_field( $data['tags'] ?? '' ),
			'is_template'    => isset( $data['is_template'] ) ? (int) $data['is_template'] : 0,
		);

		$result = $wpdb->insert( $table_name, $insert_data );

		return false !== $result ? $wpdb->insert_id : false;
	}

	/**
	 * Update an existing query.
	 *
	 * @param int   $query_id Query ID.
	 * @param int   $user_id User ID (for permission check).
	 * @param array $data Query data to update.
	 * @return bool True on success, false on failure.
	 */
	public static function update_query( $query_id, $user_id, $data ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'hwgt_saved_queries';

		$update_data = array(
			'name'          => sanitize_text_field( $data['name'] ?? '' ),
			'description'   => wp_kses_post( $data['description'] ?? '' ),
			'query_type'    => sanitize_text_field( $data['query_type'] ?? '' ),
			'query_content' => sanitize_textarea_field( $data['query_content'] ?? '' ),
			'variables'     => isset( $data['variables'] ) ? wp_json_encode( $data['variables'] ) : null,
			'tags'          => sanitize_text_field( $data['tags'] ?? '' ),
		);

		// Only update non-empty fields
		$update_data = array_filter( $update_data, function( $value ) {
			return '' !== $value && null !== $value;
		});

		$result = $wpdb->update(
			$table_name,
			$update_data,
			array(
				'id'      => $query_id,
				'user_id' => $user_id,
			)
		);

		return false !== $result;
	}

	/**
	 * Delete a saved query.
	 *
	 * @param int $query_id Query ID.
	 * @param int $user_id User ID (for permission check).
	 * @return bool True on success, false on failure.
	 */
	public static function delete_query( $query_id, $user_id ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'hwgt_saved_queries';

		$result = $wpdb->delete(
			$table_name,
			array(
				'id'      => $query_id,
				'user_id' => $user_id,
			)
		);

		return false !== $result;
	}

	/**
	 * Get a single query by ID.
	 *
	 * @param int $query_id Query ID.
	 * @param int $user_id User ID (for permission check).
	 * @return object|null Query object or null if not found.
	 */
	public static function get_query( $query_id, $user_id ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'hwgt_saved_queries';

		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM $table_name WHERE id = %d AND user_id = %d",
				$query_id,
				$user_id
			)
		);
	}

	// ========================================
	// Phase 4: Template Categories Methods
	// ========================================

	/**
	 * Get all template categories.
	 *
	 * @return array Categories with template count.
	 */
	public static function get_categories() {
		global $wpdb;
		$categories_table = $wpdb->prefix . 'hwgt_template_categories';
		$queries_table    = $wpdb->prefix . 'hwgt_saved_queries';

		$sql = "SELECT 
			c.*,
			COUNT(q.id) as template_count
		FROM $categories_table c
		LEFT JOIN $queries_table q ON c.id = q.category_id AND q.is_template = 1
		GROUP BY c.id
		ORDER BY c.sort_order ASC";

		return $wpdb->get_results( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
	}

	/**
	 * Get templates by category.
	 *
	 * @param int $category_id Category ID.
	 * @return array Templates in category.
	 */
	public static function get_templates_by_category( $category_id ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'hwgt_saved_queries';

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM $table_name 
				WHERE category_id = %d AND is_template = 1 AND is_public = 1
				ORDER BY name ASC",
				$category_id
			)
		);
	}

	// ========================================
	// Phase 4: Favorites Methods
	// ========================================

	/**
	 * Add query to user's favorites.
	 *
	 * @param int $user_id User ID.
	 * @param int $query_id Query ID.
	 * @return int|false Insert ID on success, false on failure.
	 */
	public static function add_favorite( $user_id, $query_id ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'hwgt_favorites';

		// Check if already favorited
		$exists = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM $table_name WHERE user_id = %d AND query_id = %d",
				$user_id,
				$query_id
			)
		);

		if ( $exists ) {
			return $exists; // Already favorited
		}

		$result = $wpdb->insert(
			$table_name,
			array(
				'user_id'  => $user_id,
				'query_id' => $query_id,
			)
		);

		return false !== $result ? $wpdb->insert_id : false;
	}

	/**
	 * Remove query from user's favorites.
	 *
	 * @param int $user_id User ID.
	 * @param int $query_id Query ID.
	 * @return bool True on success, false on failure.
	 */
	public static function remove_favorite( $user_id, $query_id ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'hwgt_favorites';

		$result = $wpdb->delete(
			$table_name,
			array(
				'user_id'  => $user_id,
				'query_id' => $query_id,
			)
		);

		return false !== $result;
	}

	/**
	 * Get user's favorite queries.
	 *
	 * @param int $user_id User ID.
	 * @return array Favorite queries with template info.
	 */
	public static function get_user_favorites( $user_id ) {
		global $wpdb;
		$favorites_table = $wpdb->prefix . 'hwgt_favorites';
		$queries_table   = $wpdb->prefix . 'hwgt_saved_queries';

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT q.*, f.favorited_at
				FROM $favorites_table f
				JOIN $queries_table q ON f.query_id = q.id
				WHERE f.user_id = %d
				ORDER BY f.favorited_at DESC",
				$user_id
			)
		);
	}

	/**
	 * Check if query is favorited by user.
	 *
	 * @param int $user_id User ID.
	 * @param int $query_id Query ID.
	 * @return bool True if favorited, false otherwise.
	 */
	public static function is_favorited( $user_id, $query_id ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'hwgt_favorites';

		$result = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM $table_name WHERE user_id = %d AND query_id = %d",
				$user_id,
				$query_id
			)
		);

		return ! empty( $result );
	}

	/**
	 * Increment template usage count.
	 *
	 * @param int $query_id Query ID.
	 * @return bool True on success, false on failure.
	 */
	public static function increment_usage( $query_id ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'hwgt_saved_queries';

		$result = $wpdb->query(
			$wpdb->prepare(
				"UPDATE $table_name SET usage_count = usage_count + 1 WHERE id = %d",
				$query_id
			)
		);

		return false !== $result;
	}
}
