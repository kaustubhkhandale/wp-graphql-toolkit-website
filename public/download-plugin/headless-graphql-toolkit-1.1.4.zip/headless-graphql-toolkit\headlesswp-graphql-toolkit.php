<?php
/**
 * Plugin Name: Headless GraphQL Toolkit
 * Plugin URI: https://kaustubhkhandale.github.io/wp-graphql-toolkit-website/
 * Description: Visually generate, manage, preview, and export WPGraphQL queries for Headless WordPress.
 * Version: 1.1.4
 * Author: Kaustubh Khandale
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: headless-graphql-toolkit
 * Requires at least: 6.0
 * Requires PHP: 8.0
 * Requires Plugins: wp-graphql
 *
 * @package HeadlessWPGraphQLToolkit
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define plugin constants.
define( 'HWGT_PLUGIN_FILE', __FILE__ );
define( 'HWGT_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'HWGT_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'HWGT_VERSION', '1.1.4' );
define( 'HWGT_TEXT_DOMAIN', 'headless-graphql-toolkit' );
define( 'HWGT_REST_NAMESPACE', 'hwgt/v1' );
define( 'HWGT_CAPABILITY', 'manage_options' );

// Load plugin dependencies.
require_once HWGT_PLUGIN_DIR . 'includes/class-plugin.php';

/**
 * Initialize the plugin.
 *
 * @return void
 */
function hwgt_init() {
	$plugin = new \HeadlessWPGraphQLToolkit\Plugin();
	$plugin->run();
}

// Initialize on WordPress loaded hook.
add_action( 'plugins_loaded', 'hwgt_init' );

// Register activation hook.
register_activation_hook( HWGT_PLUGIN_FILE, array( '\HeadlessWPGraphQLToolkit\Plugin', 'activate' ) );

// Register deactivation hook.
register_deactivation_hook( HWGT_PLUGIN_FILE, array( '\HeadlessWPGraphQLToolkit\Plugin', 'deactivate' ) );
