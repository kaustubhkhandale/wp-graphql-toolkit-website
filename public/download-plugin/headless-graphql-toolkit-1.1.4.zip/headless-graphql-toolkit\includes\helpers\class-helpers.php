<?php
/**
 * General Helpers Class
 *
 * @package HeadlessWPGraphQLToolkit
 */

namespace HeadlessWPGraphQLToolkit\Helpers;

use HeadlessWPGraphQLToolkit\Integrations\WPGraphQL_Compatibility;

/**
 * Helpers class - utility functions.
 */
class Helpers {

	/**
	 * Get plugin settings.
	 *
	 * @param string $key Setting key.
	 * @param mixed  $default Default value.
	 * @return mixed
	 */
	public static function get_setting( $key, $default = null ) {
		$settings = get_option( 'hwgt_settings', array() );
		return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
	}

	/**
	 * Update plugin settings.
	 *
	 * @param string $key Setting key.
	 * @param mixed  $value Setting value.
	 * @return bool
	 */
	public static function update_setting( $key, $value ) {
		$settings = get_option( 'hwgt_settings', array() );
		$settings[ $key ] = $value;
		return update_option( 'hwgt_settings', $settings );
	}

	/**
	 * Send JSON response.
	 *
	 * @param mixed $data Response data.
	 * @param int   $status HTTP status code.
	 * @param bool  $success Whether response is successful.
	 * @return void
	 */
	public static function send_json_response( $data, $status = 200, $success = true ) {
		wp_send_json(
			array(
				'success' => $success,
				'data'    => $data,
			),
			$status
		);
	}

	/**
	 * Check if WPGraphQL is active.
	 *
	 * @return bool
	 */
	public static function is_wpgraphql_active() {
		return WPGraphQL_Compatibility::is_available();
	}

	/**
	 * Check if in development mode.
	 *
	 * @return bool
	 */
	public static function is_dev_mode() {
		return defined( 'WP_DEBUG' ) && WP_DEBUG;
	}
}
