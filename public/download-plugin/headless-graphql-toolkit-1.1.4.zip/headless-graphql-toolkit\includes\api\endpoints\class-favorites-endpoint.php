<?php
/**
 * Favorites Endpoint Handler
 *
 * @package HeadlessWPGraphQLToolkit
 */

namespace HeadlessWPGraphQLToolkit\API\Endpoints;

use HeadlessWPGraphQLToolkit\Helpers\Security;
use HeadlessWPGraphQLToolkit\Database\Database;

/**
 * Favorites endpoint - manage user's favorite templates.
 */
class Favorites_Endpoint {

	/**
	 * Register the favorites endpoints.
	 *
	 * @return void
	 */
	public static function register() {
		// Get user's favorites
		register_rest_route(
			HWGT_REST_NAMESPACE,
			'/favorites',
			array(
				'methods'             => 'GET',
				'callback'            => array( self::class, 'get_favorites' ),
				'permission_callback' => array( self::class, 'check_permission' ),
			)
		);

		// Add/remove favorite
		register_rest_route(
			HWGT_REST_NAMESPACE,
			'/favorites/(?P<id>\d+)',
			array(
				array(
					'methods'             => 'POST',
					'callback'            => array( self::class, 'add_favorite' ),
					'permission_callback' => array( self::class, 'check_permission' ),
				),
				array(
					'methods'             => 'DELETE',
					'callback'            => array( self::class, 'remove_favorite' ),
					'permission_callback' => array( self::class, 'check_permission' ),
				),
			)
		);
	}

	/**
	 * Get user's favorite queries.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response Response object.
	 */
	public static function get_favorites( $request ) {
		// Check nonce
		if ( ! Security::verify_nonce( $request->get_header( 'X-WP-Nonce' ), 'wp_rest' ) ) {
			return new \WP_REST_Response(
				array( 'error' => 'Invalid nonce' ),
				403
			);
		}

		try {
			$current_user = wp_get_current_user();
			$favorites    = Database::get_user_favorites( $current_user->ID );

			$formatted_favorites = array_map(
				function( $favorite ) {
					return array(
						'id'            => (int) $favorite->id,
						'name'          => $favorite->name,
						'description'   => $favorite->description,
						'query_type'    => $favorite->query_type,
						'query_content' => $favorite->query_content,
						'usage_count'   => (int) $favorite->usage_count,
						'favorited_at'  => $favorite->favorited_at,
						'is_template'   => (bool) $favorite->is_template,
					);
				},
				$favorites
			);

			return new \WP_REST_Response(
				array(
					'success'    => true,
					'favorites'  => $formatted_favorites,
					'total'      => count( $formatted_favorites ),
				),
				200
			);
		} catch ( \Exception $e ) {
			return new \WP_REST_Response(
				array( 'error' => $e->getMessage() ),
				500
			);
		}
	}

	/**
	 * Add a query to favorites.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response Response object.
	 */
	public static function add_favorite( $request ) {
		// Check nonce
		if ( ! Security::verify_nonce( $request->get_header( 'X-WP-Nonce' ), 'wp_rest' ) ) {
			return new \WP_REST_Response(
				array( 'error' => 'Invalid nonce' ),
				403
			);
		}

		try {
			$current_user = wp_get_current_user();
			$query_id     = (int) $request->get_param( 'id' );

			// Verify query exists
			$query = Database::get_query( $query_id, $current_user->ID );
			if ( ! $query ) {
				return new \WP_REST_Response(
					array( 'error' => 'Query not found' ),
					404
				);
			}

			$favorite_id = Database::add_favorite( $current_user->ID, $query_id );

			if ( ! $favorite_id ) {
				return new \WP_REST_Response(
					array( 'error' => 'Failed to add favorite' ),
					500
				);
			}

			return new \WP_REST_Response(
				array(
					'success'     => true,
					'favorite_id' => $favorite_id,
					'message'     => 'Added to favorites',
				),
				201
			);
		} catch ( \Exception $e ) {
			return new \WP_REST_Response(
				array( 'error' => $e->getMessage() ),
				500
			);
		}
	}

	/**
	 * Remove a query from favorites.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response Response object.
	 */
	public static function remove_favorite( $request ) {
		// Check nonce
		if ( ! Security::verify_nonce( $request->get_header( 'X-WP-Nonce' ), 'wp_rest' ) ) {
			return new \WP_REST_Response(
				array( 'error' => 'Invalid nonce' ),
				403
			);
		}

		try {
			$current_user = wp_get_current_user();
			$query_id     = (int) $request->get_param( 'id' );

			$success = Database::remove_favorite( $current_user->ID, $query_id );

			if ( ! $success ) {
				return new \WP_REST_Response(
					array( 'error' => 'Failed to remove favorite' ),
					500
				);
			}

			return new \WP_REST_Response(
				array(
					'success' => true,
					'message' => 'Removed from favorites',
				),
				200
			);
		} catch ( \Exception $e ) {
			return new \WP_REST_Response(
				array( 'error' => $e->getMessage() ),
				500
			);
		}
	}

	/**
	 * Check if user has permission.
	 *
	 * @return bool
	 */
	public static function check_permission() {
		return Security::check_capability( HWGT_CAPABILITY );
	}
}
