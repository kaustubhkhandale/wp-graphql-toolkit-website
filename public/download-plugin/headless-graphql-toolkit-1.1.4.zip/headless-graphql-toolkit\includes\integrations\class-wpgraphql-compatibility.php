<?php
/**
 * WPGraphQL compatibility adapter.
 *
 * @package HeadlessWPGraphQLToolkit
 */

namespace HeadlessWPGraphQLToolkit\Integrations;

/**
 * Centralizes all direct interaction with WPGraphQL.
 */
class WPGraphQL_Compatibility {

	/**
	 * Oldest WPGraphQL version tested by this plugin.
	 */
	const MINIMUM_VERSION = '2.0.0';

	/**
	 * Get the installed WPGraphQL version.
	 *
	 * @return string|null
	 */
	public static function get_version() {
		if ( defined( 'WPGRAPHQL_VERSION' ) ) {
			return (string) WPGRAPHQL_VERSION;
		}

		if ( defined( 'WPGRAPHQL_VERSION_NUMBER' ) ) {
			return (string) WPGRAPHQL_VERSION_NUMBER;
		}

		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$plugins = get_plugins();
		return isset( $plugins['wp-graphql/wp-graphql.php']['Version'] )
			? (string) $plugins['wp-graphql/wp-graphql.php']['Version']
			: null;
	}

	/**
	 * Determine whether WPGraphQL can execute queries.
	 *
	 * @return bool
	 */
	public static function is_available() {
		return function_exists( 'graphql' );
	}

	/**
	 * Determine whether the installed version is supported.
	 *
	 * Unknown versions remain usable but are reported as unverified.
	 *
	 * @return bool
	 */
	public static function is_supported() {
		$version = self::get_version();
		return null === $version || version_compare( $version, self::MINIMUM_VERSION, '>=' );
	}

	/**
	 * Get a normalized compatibility status.
	 *
	 * @return array
	 */
	public static function get_status() {
		$available = self::is_available();
		$version   = self::get_version();
		$supported = $available && self::is_supported();

		if ( ! $available ) {
			$state   = 'missing';
			$message = 'WPGraphQL is not active. Query execution and schema tools are unavailable.';
		} elseif ( ! $supported ) {
			$state   = 'unsupported';
			$message = sprintf(
				'WPGraphQL %1$s is below the supported minimum version %2$s.',
				$version,
				self::MINIMUM_VERSION
			);
		} elseif ( null === $version ) {
			$state   = 'unverified';
			$message = 'WPGraphQL is active, but its version could not be verified.';
		} else {
			$state   = 'ready';
			$message = 'WPGraphQL is active and compatible.';
		}

		return array(
			'available'      => $available,
			'supported'      => $supported,
			'ready'          => $available && $supported,
			'state'          => $state,
			'version'        => $version,
			'minimumVersion' => self::MINIMUM_VERSION,
			'message'        => $message,
		);
	}

	/**
	 * Execute a GraphQL operation through the supported integration surface.
	 *
	 * @param string $query GraphQL query.
	 * @param array  $variables Query variables.
	 * @return array
	 * @throws \RuntimeException When WPGraphQL is unavailable or unsupported.
	 */
	public static function execute( $query, $variables = array() ) {
		$status = self::get_status();

		if ( ! $status['ready'] ) {
			throw new \RuntimeException( esc_html( $status['message'] ) );
		}

		$result = \graphql(
			array(
				'query'     => $query,
				'variables' => $variables,
			)
		);

		if ( ! is_array( $result ) ) {
			throw new \RuntimeException( 'WPGraphQL returned an unexpected response.' );
		}

		return $result;
	}
}
