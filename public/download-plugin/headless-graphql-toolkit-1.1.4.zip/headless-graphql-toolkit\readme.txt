=== Headless GraphQL Toolkit ===
Contributors: kaustubhkhandale
Tags: graphql, wpgraphql, headless, query builder, developer tools
Requires at least: 6.0
Tested up to: 7.0
Requires PHP: 8.0
Stable tag: 1.1.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Build, inspect, test, save, and export WPGraphQL queries from a focused WordPress admin toolkit.

== Description ==

Headless GraphQL Toolkit provides visual query building, schema exploration,
ready-made templates, a query playground, saved queries, and export tools for
sites using WPGraphQL.

WPGraphQL is required for schema inspection and query execution.

The plugin does not send usage data or load executable code from external
services. The optional donation link opens only after an administrator chooses
it and does not unlock any features.

Source code and build instructions are available at:
https://github.com/kaustubhkhandale/wp-graphql-headless

== Frequently Asked Questions ==

= Does this plugin require WPGraphQL? =

Yes. WPGraphQL 2.0.0 or newer provides the GraphQL schema and query execution
runtime used by this toolkit.

= Does this plugin collect data or contact external services? =

No. The toolkit operates inside WordPress and does not send telemetry. The
optional donation action opens a payment link only when an administrator
selects it.

= Are any features locked behind payment? =

No. All features included in this plugin are available without payment.

== Installation ==

1. Install and activate WPGraphQL.
2. Upload and activate Headless GraphQL Toolkit.
3. Open GraphQL Toolkit from the WordPress admin menu.

== Changelog ==

= 1.1.4 =
* Added clear clipboard feedback and tooltips for icon actions
* Improved Query Builder field layout to prevent label overlap
* Removed the unused Author URI

= 1.1.3 =
* Updated the Visit plugin site link to the official plugin website

= 1.1.2 =
* Prepared the plugin for WordPress.org directory review
* Removed unfinished premium AI controls from the free plugin
* Updated public naming, metadata, privacy disclosures, and package contents

= 1.1.1 =
* Added a safe uninstall data preference that preserves plugin data by default.
* Added explicit cleanup of saved queries, favorites, categories, and settings when administrators enable uninstall deletion.
* Included uninstall.php and server-side settings support in marketplace packages.

= 1.1.0 =
* Added schema-aware Playground field suggestions.
* Added query saving from Query Builder and Playground.
* Redesigned Saved Queries, Templates, Schema Explorer, and shared page headers.
* Added WPGraphQL compatibility checks and automated release quality tests.

= 1.0.0 =
* Initial development release.
