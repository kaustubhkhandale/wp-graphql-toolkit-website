<?php
/**
 * Main Plugin Class
 *
 * @package HeadlessWPGraphQLToolkit
 */

namespace HeadlessWPGraphQLToolkit;

/**
 * Plugin class
 */
class Plugin {

	/**
	 * Plugin constructor.
	 */
	public function __construct() {
		$this->load_dependencies();
	}

	/**
	 * Load plugin dependencies.
	 *
	 * @return void
	 */
	private function load_dependencies() {
		// Load all necessary files.
		require_once HWGT_PLUGIN_DIR . 'includes/helpers/class-constants.php';
		require_once HWGT_PLUGIN_DIR . 'includes/helpers/class-helpers.php';
		require_once HWGT_PLUGIN_DIR . 'includes/helpers/class-security.php';
		require_once HWGT_PLUGIN_DIR . 'includes/integrations/class-wpgraphql-compatibility.php';
		require_once HWGT_PLUGIN_DIR . 'includes/database/class-database.php';
		require_once HWGT_PLUGIN_DIR . 'includes/api/endpoints/class-schema-endpoint.php';
		require_once HWGT_PLUGIN_DIR . 'includes/api/endpoints/class-status-endpoint.php';
		require_once HWGT_PLUGIN_DIR . 'includes/api/endpoints/class-settings-endpoint.php';
		require_once HWGT_PLUGIN_DIR . 'includes/api/endpoints/class-templates-endpoint.php';
		require_once HWGT_PLUGIN_DIR . 'includes/api/endpoints/class-query-endpoint.php';
		require_once HWGT_PLUGIN_DIR . 'includes/api/endpoints/class-saved-queries-endpoint.php';
		require_once HWGT_PLUGIN_DIR . 'includes/api/endpoints/class-categories-endpoint.php';
		require_once HWGT_PLUGIN_DIR . 'includes/api/endpoints/class-favorites-endpoint.php';
		require_once HWGT_PLUGIN_DIR . 'includes/api/class-rest-api.php';
		require_once HWGT_PLUGIN_DIR . 'includes/admin/class-admin.php';
	}

	/**
	 * Run the plugin.
	 *
	 * @return void
	 */
	public function run() {
		// Initialize database
		do_action( 'hwgt_init' );

		// Initialize admin.
		new Admin\Admin();

		// Initialize REST API.
		new API\REST_API();

	}

	/**
	 * Activate plugin.
	 *
	 * @return void
	 */
	public static function activate() {
		// Activation runs before the plugin instance loads dependencies.
		require_once HWGT_PLUGIN_DIR . 'includes/database/class-database.php';

		// Create database tables.
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		Database\Database::create_tables();

		// Flush rewrite rules.
		flush_rewrite_rules();
	}

	/**
	 * Deactivate plugin.
	 *
	 * @return void
	 */
	public static function deactivate() {
		// Flush rewrite rules.
		flush_rewrite_rules();
	}
}
