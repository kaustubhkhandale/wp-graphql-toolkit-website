<?php
/**
 * Query Endpoint Handler
 *
 * @package HeadlessWPGraphQLToolkit
 */

namespace HeadlessWPGraphQLToolkit\API\Endpoints;

use HeadlessWPGraphQLToolkit\Helpers\Security;
use HeadlessWPGraphQLToolkit\Integrations\WPGraphQL_Compatibility;

/**
 * Query endpoint - execute and validate GraphQL queries.
 */
class Query_Endpoint {

	/**
	 * Register the query endpoint.
	 *
	 * @return void
	 */
	public static function register() {
		register_rest_route(
			HWGT_REST_NAMESPACE,
			'/query',
			array(
				'methods'             => 'POST',
				'callback'            => array( self::class, 'execute_query' ),
				'permission_callback' => array( self::class, 'check_permission' ),
				'args'                => array(
					'query'     => array(
						'type'        => 'string',
						'required'    => true,
						'description' => 'GraphQL query string',
					),
					'variables' => array(
						'type'        => 'object',
						'required'    => false,
						'description' => 'GraphQL variables',
					),
					'validate'  => array(
						'type'        => 'boolean',
						'required'    => false,
						'default'     => false,
						'description' => 'Only validate without executing',
					),
				),
			)
		);
	}

	/**
	 * Execute a GraphQL query.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response Response object.
	 */
	public static function execute_query( $request ) {
		// Check nonce
		if ( ! Security::verify_nonce( $request->get_header( 'X-WP-Nonce' ), 'wp_rest' ) ) {
			return new \WP_REST_Response(
				array( 'error' => 'Invalid nonce' ),
				403
			);
		}

		$status = WPGraphQL_Compatibility::get_status();
		if ( ! $status['ready'] ) {
			return new \WP_REST_Response(
				array(
					'error'  => $status['message'],
					'code'   => 'hwgt_wpgraphql_unavailable',
					'status' => $status,
				),
				503
			);
		}

		try {
			$query     = $request->get_param( 'query' );
			$variables = $request->get_param( 'variables' );
			$validate  = (bool) $request->get_param( 'validate' );

			if ( ! is_string( $query ) || '' === trim( $query ) ) {
				return new \WP_REST_Response(
					array( 'error' => 'Query cannot be empty' ),
					400
				);
			}

			if ( null === $variables ) {
				$variables = array();
			}

			if ( ! is_array( $variables ) ) {
				return new \WP_REST_Response(
					array( 'error' => 'Variables must be a JSON object' ),
					400
				);
			}

			// Validate query syntax
			if ( ! self::validate_query_syntax( $query ) ) {
				return new \WP_REST_Response(
					array( 'error' => 'Invalid GraphQL syntax' ),
					400
				);
			}

			if ( $validate ) {
				return new \WP_REST_Response(
					array(
						'success'   => true,
						'message'   => 'Query syntax is valid',
						'validated' => true,
					),
					200
				);
			}

			// Execute the query
			$result = WPGraphQL_Compatibility::execute( $query, $variables );

			return new \WP_REST_Response(
				array(
					'success' => ! isset( $result['errors'] ),
					'data'    => $result['data'] ?? null,
					'errors'  => $result['errors'] ?? null,
				),
				200
			);
		} catch ( \Throwable $e ) {
			return new \WP_REST_Response(
				array( 'error' => $e->getMessage() ),
				500
			);
		}
	}

	/**
	 * Validate GraphQL query syntax.
	 *
	 * @param string $query GraphQL query string.
	 * @return bool True if valid, false otherwise.
	 */
	private static function validate_query_syntax( $query ) {
		try {
			if ( ! class_exists( '\GraphQL\Language\Parser' ) ) {
				return true; // Skip validation if GraphQL-core not available
			}
			\GraphQL\Language\Parser::parse( $query );
			return true;
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	/**
	 * Check if user has permission.
	 *
	 * @return bool
	 */
	public static function check_permission() {
		return Security::check_capability( HWGT_CAPABILITY );
	}
}
